document.getElementById('contactForm').addEventListener('submit', function(event) {
    event.preventDefault();
    let isValid = true;

    function showError(input, message) {
        const errorMessage = input.nextElementSibling;
        errorMessage.textContent = message;
        errorMessage.style.display = 'block';
        isValid = false;
    }

    function clearError(input) {
        const errorMessage = input.nextElementSibling;
        errorMessage.textContent = '';
        errorMessage.style.display = 'none';
    }

    const name = document.getElementById('name');
    if (!/^[A-Za-z\s]{3,}$/.test(name.value)) {
        showError(name, 'Name must be at least 3 characters long and contain only letters.');
    } else {
        clearError(name);
    }

    const email = document.getElementById('email');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value)) {
        showError(email, 'Enter a valid email address.');
    } else {
        clearError(email);
    }

    const phone = document.getElementById('phone');
    if (!/^\d{10}$/.test(phone.value)) {
        showError(phone, 'Phone number must be exactly 10 digits.');
    } else {
        clearError(phone);
    }

    const subject = document.getElementById('subject');
    if (subject.value.length < 5) {
        showError(subject, 'Subject must be at least 5 characters long.');
    } else {
        clearError(subject);
    }

    const message = document.getElementById('message');
    if (message.value.length < 20) {
        showError(message, 'Message must be at least 20 characters long.');
    } else {
        clearError(message);
    }

    if (isValid) {
        document.getElementById('success-message').textContent = 'Form submitted successfully!';
        document.getElementById('success-message').style.color = 'green';
        successMessage.style.fontWeight = 'bold';
        this.reset();
    }
});